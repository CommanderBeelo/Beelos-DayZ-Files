class CfgPatches
{
	class Beelos_CarCovers
	{
		units[]={
			"Mustang_Cover",
			"Mustang_Cover_Winter",
			"Mustang_Cover_Desert",
			"Mustang_Cover_Civil"
		};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"DZ_Data",
			"DZ_Scripts",
			"CarCover"
		};
	};
};
class CfgMods
{
	class Beelos_CarCovers
	{
		dir="Mustang Cover";
		author="Commander Beelo - Special thanks to Callatic, HunterZ, and cloudy for their mods!";
		version="1.0";
		extra=0;
		type="mod";
		class defs
		{
			class gameScriptModule
			{
				value="";
				files[]=
				{
					"GameLabs/GameLabsDefine/Global",
					"BasicTerritoriesDefines/scripts/Common",
					"MuchCarKey/Scripts/Common",
					"MuchCarKeyDefines/scripts/Common",
					"CLDefine/scripts/Common",
					"TPDefine/scripts/Common",
					"TM/Trader/scripts/defines",
					"CarCover/Scripts/Common",
					"CarCover/scripts/3_Game"
				};
			};
			class worldScriptModule
			{
				value="";
				files[]=
				{
					"GameLabs/GameLabsDefine/Global",
					"BasicTerritoriesDefines/scripts/Common",
					"MuchCarKey/Scripts/Common",
					"MuchCarKeyDefines/scripts/Common",
					"CLDefine/scripts/Common",
					"TPDefine/scripts/Common",
					"TM/Trader/scripts/defines",
					"CarCover/Scripts/Common",
					"CarCover/Scripts/4_World"
				};
			};
			class missionScriptModule
			{
				value="";
				files[]=
				{
					"GameLabs/GameLabsDefine/Global",
					"BasicTerritoriesDefines/scripts/Common",
					"MuchCarKey/Scripts/Common",
					"MuchCarKeyDefines/scripts/Common",
					"CLDefine/scripts/Common",
					"TPDefine/scripts/Common",
					"TM/Trader/scripts/defines",
					"CarCover/Scripts/Common",
					"CarCover/Scripts/5_Mission"
				};
			};
		};
	};
};
class CfgVehicles
{
	class HouseNoDestruct;
	class Inventory_Base;
	class Container_Base;
	class WorldContainer_Base;
	class CarCoverBase;
	
	class Mustang_Cover: CarCoverBase
	{
		scope=2;
		displayName="Camo Net (DBO Mustang)";
		model="Mustang Cover\data\Mustang_Cover.p3d";
		attachments[]=
		{
			"Reflector_1_1",
			"Reflector_2_1",
			"EngineBelt",
			"mustangDoors_Driver",
			"mustangDoors_coDriver",
			"JerryCanRed",
			"GreenOilCan",
			"StorageBoxM",
			"toolboxm",
			"GunCaseM",
			"ShovelM",
			"CanisterGasoline",
			"CarBattery",
			"CarRadiator",
			"SparkPlug",
			"mustangWheel_1_1",
			"mustangWheel_1_2",
			"mustangWheel_2_1",
			"mustangWheel_2_2",
			"mustangWheel_Spare_1",
			"mustangWheel_Spare_2"
		};
	};
	class Mustang_Cover_Winter: Mustang_Cover
	{
		hiddenSelections[]=
		{
			"Carcover"
		};
		hiddenSelectionsTextures[]=
		{
			"CarCover\data\CarCoverWinter.paa"
		};
	};
	class Mustang_Cover_Desert: Mustang_Cover
	{
		hiddenSelections[]=
		{
			"Carcover"
		};
		hiddenSelectionsTextures[]=
		{
			"CarCover\data\CarCoverDesert.paa"
		};
	};
	class Mustang_Cover_Civil: Mustang_Cover
	{
		hiddenSelections[]=
		{
			"Carcover"
		};
		hiddenSelectionsTextures[]=
		{
			"CarCover\data\BlueTarp_co.paa"
		};
		hiddenSelectionsMaterials[]=
		{
			"CarCover\data\BlueTarp.rvmat"
		};
	};
};
